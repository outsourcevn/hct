﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HocCatToc.Models;
using Newtonsoft.Json;
using PagedList;
using System.Security.Cryptography;
using System.Net;
using System.IO;
using System.Text.RegularExpressions;
using Google.Apis.YouTube.v3;
using Google.Apis.Services;
using System.Threading.Tasks;
using System.Configuration;

using Google.Apis.Auth.OAuth2;

using Google.Apis.Upload;
using Google.Apis.Util.Store;

using Google.Apis.YouTube.v3.Data;
using System.Threading;
using System.Text;
namespace HocCatToc.Controllers
{
    public class AdminController : Controller
    {
        private hoccattocEntities db = new hoccattocEntities();
        // GET: Admin
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Customer(string k, int? page)
        {
            if (Config.getCookie("is_admin") == "" || Config.getCookie("is_admin") == "0") return RedirectToAction("Login", "Admin", new { message = "Bạn không được cấp quyền truy cập chức năng này" });
            if (k == null) k = "";
            var ctm = db.customers;
            var pageNumber = page ?? 1;
            var onePage = ctm.Where(o => o.phone.Contains(k) || o.email.Contains(k) || o.name.Contains(k)).OrderByDescending(f => f.id).ToPagedList(pageNumber, 20);
            if (Config.getCookie("is_admin")=="1")
            {
                int group_id = Int32.Parse(Config.getCookie("user_group_id"));
                onePage=ctm.Where(o=>o.group_id== group_id).Where(o => o.phone.Contains(k) || o.email.Contains(k) || o.name.Contains(k)).OrderByDescending(f => f.id).ToPagedList(pageNumber, 20);
            }
            ViewBag.onePage = onePage;
            ViewBag.k = k;
            return View();

        }
        public string getautofillgroup()
        {
            return JsonConvert.SerializeObject(db.groups.OrderBy(o=>o.group_name).ToList());
        }
        [HttpPost]
        public ActionResult LogOff()
        {
            Config.removeCookie("is_admin");
            Config.removeCookie("user_id");
            Config.removeCookie("user_name");
            Config.removeCookie("user_email");
            Config.removeCookie("user_phone");
            Config.removeCookie("user_group_id");
            return View();
        }
        [HttpPost]
        public ActionResult SubmitLogin(string phone, string pass)
        {
            MD5 md5Hash = MD5.Create();
            pass = Config.GetMd5Hash(md5Hash, pass);
            if (db.customers.Any(o => o.phone == phone && o.pass == pass && o.is_admin >= 1))
            {
                var us = db.customers.Where(o => o.phone == phone && o.pass == pass && o.is_admin >= 1).FirstOrDefault();
                Config.setCookie("is_admin", us.is_admin.ToString());
                Config.setCookie("user_id", us.id.ToString());
                Config.setCookie("user_name", us.name);
                Config.setCookie("user_email", us.email);
                Config.setCookie("user_phone", us.phone);
                Config.setCookie("user_group_id", us.group_id.ToString());
                return RedirectToAction("Customer");
            }
            else
            {
                    ViewBag.message = "Sai số điện thoại hoặc mật khẩu";
                    return RedirectToAction("Login", new { message = ViewBag.message });
                
            }
        }
        [HttpPost]
        public ActionResult ResetEmail(string email)
        {
            try
            {
                if (db.customers.Any(o => o.email == email))
                {
                    string mailuser = ConfigurationManager.AppSettings["mailuser"];
                    string mailpass = ConfigurationManager.AppSettings["mailpass"];//localhost:59340
                    string link = "http://hoccattoc.edu.vn/home/ConfirmReset2?email=" + email + "&code=" + db.customers.Where(o => o.email == email).OrderBy(o => o.id).FirstOrDefault().pass;//api.smartcheck.vn
                    if (Config.Sendmail(mailuser, mailpass, email, "Lấy lại mật khẩu của ứng dụng Học Cắt Tóc", "Ai đó đã dùng email này để yêu cầu lấy lại mật khấu, nếu là bạn xin xác nhận click vào đường link này để nhập lại mật khẩu " + link + ", nếu không phải là bạn xin bỏ qua email này.<br>http://HocCatToc.Edu.Vn"))
                    {
                        return RedirectToAction("ConfirmReset1", "Home", new { message = "Chúng tôi đã gửi mail đến địa chỉ email bạn cung cấp, vui lòng click vào link trong mail để đặt lại mật khẩu." });
                    }
                }
                else
                {
                    return RedirectToAction("Reset", "Home", new { message = "Không tìm thấy email này trong dữ liệu, vui lòng điền email khác mà bạn dùng để đăng ký" });
                }
            }
            catch
            {
                return RedirectToAction("Reset", "Home", new { message = "Không tìm thấy email này trong dữ liệu, vui lòng điền email khác mà bạn dùng để đăng ký" });
            }
            return View();
        }
        public ActionResult ConfirmReset1(string message)
        {
            ViewBag.Message = message;

            return View();
        }
        public ActionResult ConfirmReset2(string email, string code)
        {

            if (!db.customers.Any(o => o.email == email && o.pass == code))
            {
                return RedirectToAction("Reset", "Admin", new { message = "Không tìm thấy email này trong dữ liệu, vui lòng điền email khác mà bạn dùng để đăng ký" });
            }
            ViewBag.code = code;
            ViewBag.email = email;
            return View();
        }
        [HttpPost]
        public ActionResult ConfirmReset3(string email, string code, string pass, string pass2)
        {
            if (!db.customers.Any(o => o.email == email && o.pass == code))
            {
                return RedirectToAction("Reset", "Admin", new { message = "Không tìm thấy email này trong dữ liệu, vui lòng điền email khác mà bạn dùng để đăng ký" });
            }
            MD5 md5Hash = MD5.Create();
            string hash = Config.GetMd5Hash(md5Hash, pass);
            db.Database.ExecuteSqlCommand("update customers set pass=N'" + hash + "' where email=N'" + email + "' and pass=N'" + code + "'");
            return RedirectToAction("ConfirmReset4", "Admin", new { message = "Đổi mật khẩu thành công, xin dùng số điện thoại bạn đã đăng ký đăng nhập cùng mật khẩu mới này" });
        }
        public ActionResult ConfirmReset4(string message)
        {
            ViewBag.Message = message;
            return View();
        }
        [HttpPost]
        public string confirmAdmin(long id,int val)
        {
            try
            {
                db.Database.ExecuteSqlCommand("update customers set is_admin="+ val + " where id=" + id);
                return "1";
            }
            catch
            {
                return "0";
            }
        }
        [HttpPost]
        public string confirmUpdateGroup(long group_id,string group_name,int user_id)
        {
            try
            {
                db.Database.ExecuteSqlCommand("update customers set group_id="+ group_id + ",group_name=N'"+ group_name + "' where id=" + user_id);
                return "1";
            }
            catch
            {
                return "0";
            }
        }
        
        public ActionResult YouTube(string k, int? page)
        {
            if (Config.getCookie("is_admin") == "" || Config.getCookie("is_admin") == "0") return RedirectToAction("Login", "Admin", new { message = "Bạn không được cấp quyền truy cập chức năng này" });
            if (k == null) k = "";

            var ctm = db.videos;
            var pageNumber = page ?? 1;
            var onePage = ctm.Where(o => o.name.Contains(k) || o.des.Contains(k)).OrderByDescending(f => f.id).ToPagedList(pageNumber, 20);
            if (Config.getCookie("is_admin") == "1")
            {
                int group_id = 0;
                if (Config.getCookie("user_group_id") != "")
                {
                    group_id = Int32.Parse(Config.getCookie("user_group_id"));
                }
                else group_id = 0;
                onePage = ctm.Where(o => o.group_id == group_id).Where(o => o.name.Contains(k) || o.des.Contains(k)).OrderByDescending(f => f.id).ToPagedList(pageNumber, 20);
            }
            ViewBag.onePage = onePage;
            ViewBag.k = k;
            return View();

        }
        public ActionResult Link(string k, int? page)
        {
            if (Config.getCookie("is_admin") == "" || Config.getCookie("is_admin") == "0") return RedirectToAction("Login", "Admin", new { message = "Bạn không được cấp quyền truy cập chức năng này" });
            if (k == null) k = "";

            //var ctm = db.links;
            var pageNumber = page ?? 1;
            var onePage = db.links.OrderBy(o=>o.id).ToPagedList(pageNumber, 20);
            
            ViewBag.onePage = onePage;
            ViewBag.k = k;
            return View();

        }
        public ActionResult AddNews()
        {
            return View();
        }
        [HttpPost]
        public string addUpdateCustomer(customer cp)
        {
            MD5 md5Hash = MD5.Create();
            if (cp.pass != null && cp.pass.Trim() != "")
            {
                cp.pass = Config.GetMd5Hash(md5Hash, cp.pass);
            }
            else
            {
                if (cp.id != 0)
                {
                    cp.pass = db.customers.Find(cp.id).pass;
                }
            }
            if (cp.id == 0)
            {
                cp.date_time = DateTime.Now;
            }
            else
            {
                cp.date_time = db.customers.Find(cp.id).date_time;
            }
            return DBContext.addUpdatecustomer(cp);
        }
        [HttpPost]
        public string addUpdateVideo(video vd)
        {
           
            //vd.code = playlistItem.Snippet.ResourceId.VideoId;
            vd.create_date = DateTime.Now;
            vd.date = DateTime.Now.ToString();
            //vd.des = playlistItem.Snippet.Description;
            //vd.img = playlistItem.Snippet.Thumbnails.Medium.Url;
            //vd.link = "https://youtu.be/" + playlistItem.Snippet.ResourceId.VideoId;
            //vd.name = playlistItem.Snippet.Title;
            vd.update_date = DateTime.Now;// playlistItem.Snippet.PublishedAt;            
            if (vd.id == 0)
            {
                string rs = DBContext.addUpdateVideo(vd);
                string p = pushNoti(vd.id,vd.link);
                return rs;
            }
            else
            {
                string rs = DBContext.addUpdateVideo(vd);
                return "1";
            }
        }
        [HttpPost]
        public string sendNoti(int id, string link)
        {
            return pushNoti(id,link); 
        }
        public string pushNoti(long? id,string youtube){
            var request = WebRequest.Create("https://onesignal.com/api/v1/notifications") as HttpWebRequest;

            request.KeepAlive = true;
            request.Method = "POST";
            request.ContentType = "application/json; charset=utf-8";

            request.Headers.Add("authorization", "Basic M2JlMTdkZDctYTFkZi00YjI1LTgxYjUtYzExYjY3NTUwOTkw");
            var fvd = db.videos.Find(id);
            byte[] byteArray = Encoding.UTF8.GetBytes("{"
                                                    + "\"app_id\": \"bcba0d9d-dcd3-4231-abbb-aa428101e631\","
                                                    + "\"data\": {\"youtube\": \"" + youtube + "\",\"is_free\": \"" + fvd.is_free + "\",\"code\": \"" + id + "\"},"
                                                    + "\"contents\": {\"en\": \"Có video học cắt tóc mới \"},"
                                                    + "\"included_segments\": [\"All\"]}");

            string responseContent = null;

            try {
                using (var writer = request.GetRequestStream()) {
                    writer.Write(byteArray, 0, byteArray.Length);
                }

                using (var response = request.GetResponse() as HttpWebResponse) {
                    using (var reader = new StreamReader(response.GetResponseStream())) {
                        responseContent = reader.ReadToEnd();
                    }
                }
            }
            catch (WebException ex) {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                System.Diagnostics.Debug.WriteLine(new StreamReader(ex.Response.GetResponseStream()).ReadToEnd());
                return "0";
            }
            return youtube;
        }
        public ActionResult uploadimgproduct()
        {
          
            var fName = "";
            try
            {
                foreach (string fileName in Request.Files)
                {
                    HttpPostedFileBase file = Request.Files[fileName];
                    //if (!Config.IsImage(file)) return Json(new { Message = "/images/invalidimage.png" }, JsonRequestBehavior.AllowGet);
                    //Save file content goes here
                    if (file != null && file.ContentLength > 0)
                    {
                        var originalDirectory = new DirectoryInfo(string.Format("{0}images\\products", Server.MapPath(@"\")));
                        string strDay = DateTime.Now.ToString("yyyyMM");
                        string pathString = System.IO.Path.Combine(originalDirectory.ToString(), strDay);

                        var _fileName = Guid.NewGuid().ToString("N") + ".jpg";

                        bool isExists = System.IO.Directory.Exists(pathString);

                        if (!isExists)
                            System.IO.Directory.CreateDirectory(pathString);

                        var path = string.Format("{0}\\{1}", pathString, _fileName);
                        file.SaveAs(path);
                    
                        fName = "/images/products/" + strDay + "/" + _fileName;
                    }
                }
            }
            catch (Exception ex)
            {

            }
            return Json(new { Message = fName }, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public string addUpdateGroup(group cp)
        {
            return DBContext.addUpdateGroup(cp);
        }
        [HttpPost]
        public string addUpdateLink(link cp)
        {
            return DBContext.addUpdateLink(cp);
        }
        [HttpPost]
        public string deleteCustomer(int cpId)
        {
            return DBContext.deletecustomer(cpId);
        }
        [HttpPost]
        public string deleteGroup(int cpId)
        {
            return DBContext.deletegroup(cpId);
        }
        [HttpPost]
        public string deleteVideo(int cpId)
        {
            return DBContext.deletevideo(cpId);
        }
        public string getcatvideo(string keyword)
        {
            if (keyword == null) keyword = "";
            var p = (from q in db.cats orderby q.name ascending select new { label = q.name, value = q.id }).ToList().Distinct();
            return JsonConvert.SerializeObject(p);
        }
        public class result
        {
            public string link { get; set; }
            public string name { get; set; }
            public string code { get; set; }
            public string img { get; set; }
            public string des { get; set; }
            public string tags { get; set; }
            public string date { get; set; }
            public string view { get; set; }
        }
        [HttpPost]
        public async Task<string> getLink()
        {
            try
            {
                //UserCredential credential;
                //using (var stream = new FileStream(Server.MapPath("/")+"client_secret_1093025207945-ofcjaocflk4jrqrrtv55pkn97qko4uv2.apps.googleusercontent.com.json", FileMode.Open, FileAccess.Read))
                //{
                //    credential = await GoogleWebAuthorizationBroker.AuthorizeAsync(
                //        GoogleClientSecrets.Load(stream).Secrets,
                //        // This OAuth 2.0 access scope allows for full read/write access to the
                //        // authenticated user's account.
                //        new[] { YouTubeService.Scope.Youtube },
                //        "user",
                //        CancellationToken.None,
                //        new FileDataStore(this.GetType().ToString())
                //    );
                //}

                //var yt = new YouTubeService(new BaseClientService.Initializer()
                //{
                //    HttpClientInitializer = credential,
                //    ApplicationName = this.GetType().ToString()
                //});
                string rs = "";
                var gr = db.groups.Find(1);
                YouTubeService yt = new YouTubeService(new BaseClientService.Initializer() { ApiKey = "AIzaSyBSfppTmXkxgfbV9YrinJ3Tk6HYGNrBHk8"});//AIzaSyD3Hm85CbEv-9QFpw8ARzcQuaF4ZLYOtlY
                    try
                    {
                        var playlistItemsListRequest = yt.PlaylistItems.List("snippet");
                        playlistItemsListRequest.PlaylistId = "PLcajz0E4AOQzVJbDgsfZJBFKIO1mj0ObC";
                        playlistItemsListRequest.MaxResults = 50;
                        //playlistItemsListRequest.PageToken = nextPageToken;

                        // Retrieve the list of videos uploaded to the authenticated user's channel.
                        var playlistItemsListResponse = await playlistItemsListRequest.ExecuteAsync();

                        foreach (var playlistItem in playlistItemsListResponse.Items)
                        {
                            if (!db.videos.Any(o => o.code == playlistItem.Snippet.ResourceId.VideoId)) {
                                try
                                {
                                    video vd = new video();
                                    vd.code = playlistItem.Snippet.ResourceId.VideoId;
                                    vd.create_date = playlistItem.Snippet.PublishedAt;
                                    vd.date = playlistItem.Snippet.PublishedAt.ToString();
                                    vd.des = playlistItem.Snippet.Description;
                                    vd.img = playlistItem.Snippet.Thumbnails.Medium.Url;
                                    vd.link = "https://youtu.be/" + playlistItem.Snippet.ResourceId.VideoId;
                                    vd.name = playlistItem.Snippet.Title;
                                    vd.update_date = playlistItem.Snippet.PublishedAt;
                                    vd.group_id = gr.id;
                                    vd.group_name = gr.group_name;
                                    // Print information about each video.
                                    //Console.WriteLine("{0} ({1})", playlistItem.Snippet.Title, playlistItem.Snippet.ResourceId.VideoId);
                                    //var videoRequest = yt.Videos.List("snippet");
                                    //videoRequest.Id = playlistItem.Snippet.ResourceId.VideoId;
                                    //videoRequest.MaxResults = 1;
                                    //var videoItemRequestResponse = await videoRequest.ExecuteAsync();
                                    //// Get the videoID of the first video in the list
                                    //var video = videoItemRequestResponse.Items[0];
                                    //var duration = video.ContentDetails.Duration;
                                    db.videos.Add(vd);
                                    db.SaveChanges();
                                }catch(Exception ex){
                                    
                                }
                            }
                            else
                            {
                                db.Database.ExecuteSqlCommand("update video set name=N'" + playlistItem.Snippet.Title + "', des=N'" + playlistItem.Snippet.Description + "' where code=N'" + playlistItem.Snippet.ResourceId.VideoId + "'");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        //rs += ex.ToString();
                    }
                    string getList2 = await getChenningChan();
                    string getList3 = await getHungCuong1();
                    return "1";
            }
            catch(Exception ex233)
            {
                return ex233.ToString();
            }
            //Json("", JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public async Task<string> getChenningChan()
        {
            try
            {
                string rs = "";
                var gr = db.groups.Find(2);
                YouTubeService yt = new YouTubeService(new BaseClientService.Initializer() { ApiKey = "AIzaSyCrLIAbN7a-jvh0eCi3Owp7MhJBQ7F4GRg"});
                try
                {
                    var playlistItemsListRequest = yt.PlaylistItems.List("snippet");
                    playlistItemsListRequest.PlaylistId = "PLqMfsiw2iHVV7PBkB-tleAes8wqxzUKeY";
                    playlistItemsListRequest.MaxResults = 50;
                    //playlistItemsListRequest.PageToken = nextPageToken;

                    // Retrieve the list of videos uploaded to the authenticated user's channel.
                    var playlistItemsListResponse = await playlistItemsListRequest.ExecuteAsync();

                    foreach (var playlistItem in playlistItemsListResponse.Items)
                    {
                        if (!db.videos.Any(o => o.code == playlistItem.Snippet.ResourceId.VideoId))
                        {
                            try
                            {
                                video vd = new video();
                                vd.code = playlistItem.Snippet.ResourceId.VideoId;
                                vd.create_date = playlistItem.Snippet.PublishedAt;
                                vd.date = playlistItem.Snippet.PublishedAt.ToString();
                                vd.des = playlistItem.Snippet.Description;
                                vd.img = playlistItem.Snippet.Thumbnails.Medium.Url;
                                vd.link = "https://youtu.be/" + playlistItem.Snippet.ResourceId.VideoId;
                                vd.name = playlistItem.Snippet.Title;
                                vd.update_date = playlistItem.Snippet.PublishedAt;
                                vd.group_id = gr.id;
                                vd.group_name = gr.group_name;                               
                                db.videos.Add(vd);
                                db.SaveChanges();
                            }
                            catch (Exception ex)
                            {

                            }
                        }
                        else
                        {
                            db.Database.ExecuteSqlCommand("update video set name=N'" + playlistItem.Snippet.Title + "', des=N'" + playlistItem.Snippet.Description + "' where code=N'" + playlistItem.Snippet.ResourceId.VideoId + "'");
                        }
                    }
                }
                catch (Exception ex)
                {
                    //rs += ex.ToString();
                }
                return "1";
            }
            catch
            {
                return "0";
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public async Task<string> getHungCuong1()
        {
            try
            {
                string rs = "";
                var gr = db.groups.Find(3);
                YouTubeService yt = new YouTubeService(new BaseClientService.Initializer() { ApiKey = "AIzaSyD3Hm85CbEv-9QFpw8ARzcQuaF4ZLYOtlY" });
                try
                {
                    var playlistItemsListRequest = yt.PlaylistItems.List("snippet");
                    playlistItemsListRequest.PlaylistId = "PLG9IG7DcNxVeFEpIcfVnD3xuKHugf1EpJ";
                    playlistItemsListRequest.MaxResults = 50;
                    //playlistItemsListRequest.PageToken = nextPageToken;

                    // Retrieve the list of videos uploaded to the authenticated user's channel.
                    var playlistItemsListResponse = await playlistItemsListRequest.ExecuteAsync();

                    foreach (var playlistItem in playlistItemsListResponse.Items)
                    {
                        if (!db.videos.Any(o => o.code == playlistItem.Snippet.ResourceId.VideoId))
                        {
                            try
                            {
                                video vd = new video();
                                vd.code = playlistItem.Snippet.ResourceId.VideoId;
                                vd.create_date = playlistItem.Snippet.PublishedAt;
                                vd.date = playlistItem.Snippet.PublishedAt.ToString();
                                vd.des = playlistItem.Snippet.Description;
                                vd.img = playlistItem.Snippet.Thumbnails.Medium.Url;
                                vd.link = "https://youtu.be/" + playlistItem.Snippet.ResourceId.VideoId;
                                vd.name = playlistItem.Snippet.Title;
                                vd.update_date = playlistItem.Snippet.PublishedAt;
                                vd.group_id = gr.id;
                                vd.group_name = gr.group_name;
                                db.videos.Add(vd);
                                db.SaveChanges();
                            }
                            catch (Exception ex)
                            {

                            }
                        }
                        else
                        {
                            db.Database.ExecuteSqlCommand("update video set name=N'" + playlistItem.Snippet.Title + "', des=N'" + playlistItem.Snippet.Description + "' where code=N'" + playlistItem.Snippet.ResourceId.VideoId + "'");
                        }
                    }
                }
                catch (Exception ex)
                {
                    //rs += ex.ToString();
                }
                return "1";
            }
            catch
            {
                return "0";
            }
        }
        public ActionResult Group(string k, int? page)
        {
            if (Config.getCookie("is_admin") == "" || Config.getCookie("is_admin") == "0") return RedirectToAction("Login", "Admin", new { message = "Bạn không được cấp quyền truy cập chức năng này" });
            if (k == null) k = "";
            var ctm = db.groups;
            var pageNumber = page ?? 1;
            var onePage = ctm.Where(o => o.group_name.Contains(k)).OrderByDescending(f => f.id).ToPagedList(pageNumber, 20);
            ViewBag.onePage = onePage;
            ViewBag.k = k;
            return View();
        }
        //public List<YouTubePlayList> GetUserPlayLists(string userEmail)
        //{
        //    List<YouTubePlayList> playLists = new List<YouTubePlayList>();

        //    try
        //    {
        //        YouTubeServiceClient service = new YouTubeServiceClient();
        //        service.GetUserPlayListsAsync(userEmail, playLists).Wait();
        //    }
        //    catch (AggregateException ex)
        //    {
        //        foreach (var e in ex.InnerExceptions)
        //        {
        //            //TODO: Add Logging
        //        }
        //    }

        //    return playLists;
        //}
        public string Search(String data, string key, int i, string stop)
        {
            string source = data;
            var x = source.IndexOf(key);
            string extract = source.Substring(source.IndexOf(key) + i);
            string result = extract.Substring(0, extract.IndexOf(stop));
            return result;
        }

        public string DeleteHtmlTags(string value)
        {
            var str1 = Regex.Replace(value, @"<[^>]+|&nbsp;", "").Trim();
            var str2 = Regex.Replace(str1, @"\s{2,}", " ");
            return str2;
        }
        [HttpPost]
        public string generateCode(long user_id, string group_id_list)
        {
            db.Database.ExecuteSqlCommand("delete from  customer_code where customer_id=" + user_id);
            var p = (from q in db.videos where (q.group_id_list.Contains(group_id_list) || group_id_list.Contains(q.group_id_list) || group_id_list.Contains(","+q.id+",")) select q).ToList();
            for (int i = 0; i < p.Count; i++)
            {
                customer_code cc = new customer_code();
                cc.code = (int)(user_id * 100 + p[i].id);// i * 10 + DateTime.Now.Day;
                cc.customer_id = user_id;
                cc.video_id = p[i].id;
                db.customer_code.Add(cc);
                db.SaveChanges();
            }
            return "1";
        }
        public string isMoney(long? user_id)
        {
            if (db.customer_code.Any(o => o.customer_id == user_id) && db.customer_code.Where(o => o.customer_id == user_id).FirstOrDefault().code != null)//o.video_id == video_id && o.code == code && 
            {
                return "1";
            }
            return "0";
        }
        public ActionResult Login(string message)
        {
            ViewBag.message = message;
            return View();
        }
    }
}