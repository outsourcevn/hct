﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HocCatToc.Controllers
{
    public class linkController : Controller
    {
        // GET: link
        public ActionResult Index()
        {
            return View();
        }
    }
}